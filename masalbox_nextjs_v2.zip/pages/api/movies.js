export default function handler(req, res) {
  const movies = [
    { id: 'm1', title: 'Kayıp Balon', age: '3-5', duration: '12 dk', slug: 'kayip-balon' },
    { id: 'm2', title: 'Uzay Macerası', age: '6-9', duration: '22 dk', slug: 'uzay-macerasi' },
    { id: 'm3', title: 'Orman Şarkısı', age: '3-5', duration: '8 dk', slug: 'orman-sarkisi' }
  ]
  res.status(200).json(movies)
}