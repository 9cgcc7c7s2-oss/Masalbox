import Header from '../components/Header'
import MovieCard from '../components/MovieCard'
import { useState } from 'react'

const sampleMovies = [
  { id: 'm1', title: 'Kayıp Balon', age: '3-5', duration: '12 dk', slug: 'kayip-balon', thumbnail: '/images/balon.jpg', description: 'Küçük bir balonun macerası — dostluk ve cesaret temalı kısa film.' },
  { id: 'm2', title: 'Uzay Macerası', age: '6-9', duration: '22 dk', slug: 'uzay-macerasi', thumbnail: '/images/uzay.jpg', description: 'Bir grup çocuğun hayal gücüyle başlayan uzay yolculuğu.' },
  { id: 'm3', title: 'Orman Şarkısı', age: '3-5', duration: '8 dk', slug: 'orman-sarkisi', thumbnail: '/images/orman.jpg', description: 'Doğa sevgisi ve hayvan dostlukları üzerine müzikal kısa.' }
]

export default function Home() {
  const [ageFilter, setAgeFilter] = useState('all')
  const filtered = ageFilter === 'all' ? sampleMovies : sampleMovies.filter(m => m.age === ageFilter)

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-white p-6">
      <Header />
      <div className="max-w-5xl mx-auto mt-6 flex gap-3 items-center">
        <label className="text-sm text-gray-600">Yaşa göre filtre:</label>
        <select value={ageFilter} onChange={e => setAgeFilter(e.target.value)} className="rounded-md p-2 border">
          <option value="all">Tümü</option>
          <option value="3-5">3–5</option>
          <option value="6-9">6–9</option>
          <option value="9-12">9–12</option>
        </select>
      </div>
      <main className="max-w-5xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 mt-6">
        {filtered.map(movie => (<MovieCard key={movie.id} movie={movie} />))}
      </main>
      <footer className="max-w-5xl mx-auto mt-8 text-center text-xs text-gray-500">© 2025 MasalBox — Güvenli içerik & ebeveyn kontrollü deneyim</footer>
    </div>
  )
}