import { useRouter } from 'next/router'
const movieData = {
  'kayip-balon': { title: 'Kayıp Balon', description: 'Küçük bir balonun macerası — dostluk ve cesaret temalı kısa film.', videoUrl: 'https://example.com/secure-token.mp4' },
  'uzay-macerasi': { title: 'Uzay Macerası', description: 'Bir grup çocuğun hayal gücüyle başlayan uzay yolculuğu.', videoUrl: 'https://example.com/secure-token.mp4' },
  'orman-sarkisi': { title: 'Orman Şarkısı', description: 'Doğa sevgisi ve hayvan dostlukları üzerine müzikal kısa.', videoUrl: 'https://example.com/secure-token.mp4' }
}
export default function MoviePage() {
  const router = useRouter()
  const { slug } = router.query
  const movie = movieData[slug]
  if (!movie) return <div className="p-6 text-center">Yükleniyor...</div>
  return (
    <div className="min-h-screen bg-white p-6">
      <div className="max-w-4xl mx-auto">
        <button onClick={() => router.back()} className="text-sm text-indigo-600">← Geri dön</button>
        <h1 className="text-2xl font-bold mt-3">{movie.title}</h1>
        <div className="mt-4 bg-black aspect-video rounded-lg flex items-center justify-center text-white">
          <video controls src={movie.videoUrl} className="w-full h-full rounded-lg" />
        </div>
        <p className="mt-4 text-gray-700">{movie.description}</p>
      </div>
    </div>
  )
}