export default function Header() {
  return (
    <header className="max-w-5xl mx-auto mb-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-indigo-400 rounded-full flex items-center justify-center text-white text-xl font-bold shadow-lg">M</div>
          <h1 className="text-2xl font-extrabold">MasalBox — Çocuk Filmleri</h1>
        </div>
        <nav className="flex gap-2">
          <button className="px-3 py-1 rounded-md bg-indigo-100 text-indigo-700">Giriş Yap</button>
          <button className="px-3 py-1 rounded-md bg-yellow-100 text-yellow-800">Ebeveyn Paneli</button>
        </nav>
      </div>
    </header>
  )
}