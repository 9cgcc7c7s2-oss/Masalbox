import Link from 'next/link'
export default function MovieCard({ movie }) {
  return (
    <Link href={`/movie/${movie.slug}`} className="block rounded-2xl shadow bg-white overflow-hidden hover:shadow-lg transition">
      <img src={movie.thumbnail} alt={movie.title} className="w-full h-40 object-cover" />
      <div className="p-3">
        <h3 className="font-semibold text-lg">{movie.title}</h3>
        <p className="text-xs text-gray-500">{movie.age} • {movie.duration}</p>
        <p className="text-sm mt-2 line-clamp-2">{movie.description}</p>
      </div>
    </Link>
  )
}